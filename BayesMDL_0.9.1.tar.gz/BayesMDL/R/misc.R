#################################################
######      Misc functions                #######
#################################################

#### create meta or eta from non-zero-one sequences
loc2dirac = function(loc, N){
  dirac = rep(0, N);
  dirac[loc] = 1; 
  return(dirac);
}

