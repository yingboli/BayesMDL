###################################################################
######    Bayesian MDL for multiple changepoint detection   #######
###################################################################

######## Inputs #######
## X: a vector of length N. NOT pre-processed to zero mean.
## month: a vector of length N. Take value in {1, 2, ..., 12}.
## meta: a vector of 0-1 indicators. 
##      Length is N, first p elemenets are always 0.
## nu: default value 5
## a: default value 1
## b1: dafault value 19 (for annual data), 239 (for monthly data)
## b2: dafault value 3 (for annual data), 47 (for monthly data)
## type: 'annual' or 'monthly'

######## Outputs ########
## map200: 200 * (N + 3) matrix
##         200 top models with highest posterior probability that MCMC visited
##         along with mdl, phi, sigmasq
## Eta: (iter / thin + 1) * (N + 3) matrix
##         MCMC samples of change point configuration (model) eta 

bmdl = function(X, month = NULL, meta = NULL, iter = 1e4, thin = max(1, iter / 1e3), 
				type = 'monthly', p = 3, fit = 'marlik', penalty = 'bmdl', nu = 5, 
				a = 1, b1 = 19 * (type == 'annual') + 239 * (type == 'monthly'), 
				b2 = (b1 - 4) / 5, start.eta = NULL, track.time = TRUE, 
				show.summary = 10, show.month = FALSE, start.year = 1){

  t.start = proc.time();

  change.rate = 0;

  N = length(X);  
  
  ## pre-process meta
  ## for now, non-dirac meta can only be used for annual data!!!
  if(length(meta) < N){
  	meta = loc2dirac(meta, N); 
  }
  if(length(meta) > N)
    stop('Length of metadata cannot exceed length of time series.')
    
  ## output matrices
  map200 = matrix(NA, ncol = N + p + 2, nrow = 200);
  mcmc = matrix(NA, ncol = N + p + 2, nrow = round(iter / thin) + 1);
  colnames(map200) = colnames(mcmc) = c(paste('eta', 1:N, sep = ''), 'mdl', paste('phi', 1:p, sep = ''), 'sigmasq');

  ## initial values of eta 
  if(length(start.eta) == 0)
    eta = rbinom(N, 1, sort(runif(2, 0, 0.05))[meta + 1]);	## vector of change point, start value
  if(length(start.eta) == N)
    eta = start.eta;
  if(length(start.eta) < N && length(start.eta) > 0)
    eta = loc2dirac(start.eta, N);
  if(length(start.eta) > N)
    stop('Error in start.eta: length of changepoint configuration cannot exceed length of time series.')
  eta[1:p] = 0;
  
  ## initial values
  if(type == 'annual'){
  	month = rep(1, N);
  	period = 1;
  }
  if(type == 'monthly'){
  	if(length(month) == 0)
  	  month = rep(1:12, ceiling(N / 12))[1:N];
  	period = 12;
  }
  inference = bmdl.eta(X, month, eta, meta, p, fit, penalty, nu, a, b1, b2, period);
  current = list(eta = eta, inference = inference, change.eta = TRUE);  
  mcmc[1, ] = map200[1, ] = unlist(current)[1 : (N + p + 2)];  
  
  ## Start MCMC
  for(it in 1:iter){
  	
  	## Use MH.flip with probablity 80%, use MH.swap with probability 20%
    action = sample(c('flip', 'swap'), 1, prob = c(0.8, 0.2), replace = TRUE);
    ## Metropolis-Hastings update gamma  
    if(action == 'flip')	
  	  current = bmdl.MH.flip(X, month, current, meta, p, fit, penalty, nu, a, b1, b2, period);
    if(action == 'swap')	
  	  current = bmdl.MH.swap(X, month, current, meta, p, fit, penalty, nu, a, b1, b2, period); 

    ## try to put the new eta to map200 if good
    if(current$change.eta == TRUE){
      change.rate = change.rate + 1 / iter;
      
      tmpk = which(c(current$inference$mdl) > map200[, N + 1]);
      if(length(tmpk) == 0)
        k = 0;
      if(length(tmpk) > 0)
  	    k = max(tmpk);
  	  if(k < 200 && is.na(map200[k + 1, N + 1]))
  	    map200[(k + 1), ] = unlist(current)[1 : (N + p + 2)];
  	  if(k < 200 && sum(map200[k + 1, 1:N] != current$eta) > 0){
  	    if(k == 199)
  	      map200[200, ] = unlist(current)[1 : (N + p + 2)];
  	    if(k < 199){
  	      map200[(k + 2):200, ] = map200[(k + 1):199, ];
  	      map200[(k + 1), ] = unlist(current)[1 : (N + p + 2)];
  	    }
  	  }
  	}
  	
  	## save Markov chains    
    if(it %% thin == 0){
  	  mcmc[it / thin + 1, ] = unlist(current)[1 : (N + p + 2)];
      
      ## show: x0% completed
      if( (it * 10) %% iter == 0 && it != iter  && track.time == TRUE)
        cat(paste( (it * 100) / iter), '% completed...\n', sep = '');
      if( it == iter  && track.time == TRUE){
        cat(paste( (it * 100) / iter), '% completed.\n', sep = '');
        cat('\n');
      } 
    }
  }

  ## show summary: top 10 models
  if(show.summary > 0){
  	
  	cat('accept eta: ', change.rate, '\n');
    cat('Top changepoint configurations: \n');
    if(type == 'annual'){
      for(r in 1:show.summary)
  	    cat(which(map200[r, 1:N] == 1) + start.year - 1, ' mdl =', map200[r, N + 1], '\n', sep = ' ');
  	}
    if(type == 'monthly' && show.month == TRUE){
      year = (start.year + c(rep(0, 13 - month[1]), c(matrix(rep(1 : ceiling((N - (13 - month[1])) / 12), 12), nrow = 12, byrow = TRUE))))[1 : N]; 
      yearmonth = paste(year, month.abb[month], sep = '')  
      for(r in 1:show.summary)
  	    cat(yearmonth[which(map200[r, 1:N] == 1)], ' mdl =', map200[r, N + 1], '\n', sep = ' ');
  	}
    if(type == 'monthly' && show.month == FALSE){
      for(r in 1:show.summary)
  	    cat(which(map200[r, 1:N] == 1), ' mdl =', map200[r, N + 1], '\n', sep = ' ');
  	}

  }
  
  input.parameters = list(X = X, month = month, meta = meta, iter = iter, thin = thin, type = type, p = p, nu = nu, a = a, b1 = b1, b2 = b2, period = period, start.year = start.year);
  
  ## track time
  if(track.time == TRUE){
    t.finish = proc.time();
    cat('Time used (in second): \n')
    print(t.finish - t.start);
    cat('\n');
  }

  return( list(mcmc = mcmc, map200 = map200, input.parameters = input.parameters) );
}

  
  
  
  
